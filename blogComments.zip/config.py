COMMENTS_TABLE_NAME = "blogComments"
CUSTOMER_TABLE_NAME = 'blogCustomer'
AWS_REGION = "eu-west-1"
